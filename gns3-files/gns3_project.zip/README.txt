Starter project untuk P2-P3. Import topologi_isp.gns3 ke GNS3, kemudian tambahkan node dan konfigurasi final sesuai implementasi kelompok.
